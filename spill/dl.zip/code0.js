gdjs.First_32layoutCode = {};


gdjs.First_32layoutCode.GDLaser2BlueObjects1= [];
gdjs.First_32layoutCode.GDLaser2BlueObjects2= [];
gdjs.First_32layoutCode.GDLaser2BlueObjects3= [];
gdjs.First_32layoutCode.GDLaser2BlueObjects4= [];
gdjs.First_32layoutCode.GDLaser2BlueObjects5= [];
gdjs.First_32layoutCode.GDLaser2BlueObjects6= [];
gdjs.First_32layoutCode.GDGrassCenterTextureObjects1= [];
gdjs.First_32layoutCode.GDGrassCenterTextureObjects2= [];
gdjs.First_32layoutCode.GDGrassCenterTextureObjects3= [];
gdjs.First_32layoutCode.GDGrassCenterTextureObjects4= [];
gdjs.First_32layoutCode.GDGrassCenterTextureObjects5= [];
gdjs.First_32layoutCode.GDGrassCenterTextureObjects6= [];
gdjs.First_32layoutCode.GDRedButtonObjects1= [];
gdjs.First_32layoutCode.GDRedButtonObjects2= [];
gdjs.First_32layoutCode.GDRedButtonObjects3= [];
gdjs.First_32layoutCode.GDRedButtonObjects4= [];
gdjs.First_32layoutCode.GDRedButtonObjects5= [];
gdjs.First_32layoutCode.GDRedButtonObjects6= [];
gdjs.First_32layoutCode.GDGreenButtonObjects1= [];
gdjs.First_32layoutCode.GDGreenButtonObjects2= [];
gdjs.First_32layoutCode.GDGreenButtonObjects3= [];
gdjs.First_32layoutCode.GDGreenButtonObjects4= [];
gdjs.First_32layoutCode.GDGreenButtonObjects5= [];
gdjs.First_32layoutCode.GDGreenButtonObjects6= [];
gdjs.First_32layoutCode.GDStarObjects1= [];
gdjs.First_32layoutCode.GDStarObjects2= [];
gdjs.First_32layoutCode.GDStarObjects3= [];
gdjs.First_32layoutCode.GDStarObjects4= [];
gdjs.First_32layoutCode.GDStarObjects5= [];
gdjs.First_32layoutCode.GDStarObjects6= [];
gdjs.First_32layoutCode.GDCastleCenterTextureObjects1= [];
gdjs.First_32layoutCode.GDCastleCenterTextureObjects2= [];
gdjs.First_32layoutCode.GDCastleCenterTextureObjects3= [];
gdjs.First_32layoutCode.GDCastleCenterTextureObjects4= [];
gdjs.First_32layoutCode.GDCastleCenterTextureObjects5= [];
gdjs.First_32layoutCode.GDCastleCenterTextureObjects6= [];
gdjs.First_32layoutCode.GDSpaceship2GreenObjects1= [];
gdjs.First_32layoutCode.GDSpaceship2GreenObjects2= [];
gdjs.First_32layoutCode.GDSpaceship2GreenObjects3= [];
gdjs.First_32layoutCode.GDSpaceship2GreenObjects4= [];
gdjs.First_32layoutCode.GDSpaceship2GreenObjects5= [];
gdjs.First_32layoutCode.GDSpaceship2GreenObjects6= [];
gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects1= [];
gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects2= [];
gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects3= [];
gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects4= [];
gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects5= [];
gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects6= [];

gdjs.First_32layoutCode.conditionTrue_0 = {val:false};
gdjs.First_32layoutCode.condition0IsTrue_0 = {val:false};
gdjs.First_32layoutCode.condition1IsTrue_0 = {val:false};
gdjs.First_32layoutCode.condition2IsTrue_0 = {val:false};
gdjs.First_32layoutCode.conditionTrue_1 = {val:false};
gdjs.First_32layoutCode.condition0IsTrue_1 = {val:false};
gdjs.First_32layoutCode.condition1IsTrue_1 = {val:false};
gdjs.First_32layoutCode.condition2IsTrue_1 = {val:false};

gdjs.First_32layoutCode.func = function(runtimeScene, context) {
context.startNewFrame();
gdjs.First_32layoutCode.GDLaser2BlueObjects1.length = 0;
gdjs.First_32layoutCode.GDLaser2BlueObjects2.length = 0;
gdjs.First_32layoutCode.GDLaser2BlueObjects3.length = 0;
gdjs.First_32layoutCode.GDLaser2BlueObjects4.length = 0;
gdjs.First_32layoutCode.GDLaser2BlueObjects5.length = 0;
gdjs.First_32layoutCode.GDLaser2BlueObjects6.length = 0;
gdjs.First_32layoutCode.GDGrassCenterTextureObjects1.length = 0;
gdjs.First_32layoutCode.GDGrassCenterTextureObjects2.length = 0;
gdjs.First_32layoutCode.GDGrassCenterTextureObjects3.length = 0;
gdjs.First_32layoutCode.GDGrassCenterTextureObjects4.length = 0;
gdjs.First_32layoutCode.GDGrassCenterTextureObjects5.length = 0;
gdjs.First_32layoutCode.GDGrassCenterTextureObjects6.length = 0;
gdjs.First_32layoutCode.GDRedButtonObjects1.length = 0;
gdjs.First_32layoutCode.GDRedButtonObjects2.length = 0;
gdjs.First_32layoutCode.GDRedButtonObjects3.length = 0;
gdjs.First_32layoutCode.GDRedButtonObjects4.length = 0;
gdjs.First_32layoutCode.GDRedButtonObjects5.length = 0;
gdjs.First_32layoutCode.GDRedButtonObjects6.length = 0;
gdjs.First_32layoutCode.GDGreenButtonObjects1.length = 0;
gdjs.First_32layoutCode.GDGreenButtonObjects2.length = 0;
gdjs.First_32layoutCode.GDGreenButtonObjects3.length = 0;
gdjs.First_32layoutCode.GDGreenButtonObjects4.length = 0;
gdjs.First_32layoutCode.GDGreenButtonObjects5.length = 0;
gdjs.First_32layoutCode.GDGreenButtonObjects6.length = 0;
gdjs.First_32layoutCode.GDStarObjects1.length = 0;
gdjs.First_32layoutCode.GDStarObjects2.length = 0;
gdjs.First_32layoutCode.GDStarObjects3.length = 0;
gdjs.First_32layoutCode.GDStarObjects4.length = 0;
gdjs.First_32layoutCode.GDStarObjects5.length = 0;
gdjs.First_32layoutCode.GDStarObjects6.length = 0;
gdjs.First_32layoutCode.GDCastleCenterTextureObjects1.length = 0;
gdjs.First_32layoutCode.GDCastleCenterTextureObjects2.length = 0;
gdjs.First_32layoutCode.GDCastleCenterTextureObjects3.length = 0;
gdjs.First_32layoutCode.GDCastleCenterTextureObjects4.length = 0;
gdjs.First_32layoutCode.GDCastleCenterTextureObjects5.length = 0;
gdjs.First_32layoutCode.GDCastleCenterTextureObjects6.length = 0;
gdjs.First_32layoutCode.GDSpaceship2GreenObjects1.length = 0;
gdjs.First_32layoutCode.GDSpaceship2GreenObjects2.length = 0;
gdjs.First_32layoutCode.GDSpaceship2GreenObjects3.length = 0;
gdjs.First_32layoutCode.GDSpaceship2GreenObjects4.length = 0;
gdjs.First_32layoutCode.GDSpaceship2GreenObjects5.length = 0;
gdjs.First_32layoutCode.GDSpaceship2GreenObjects6.length = 0;
gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects1.length = 0;
gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects2.length = 0;
gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects3.length = 0;
gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects4.length = 0;
gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects5.length = 0;
gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects6.length = 0;


{


gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.First_32layoutCode.condition0IsTrue_0.val) {

{ //Subevents

{



}

} //End of subevents
}

}


{



{



{ //Subevents

{



}


{

gdjs.First_32layoutCode.GDSpaceship2GreenObjects3.createFrom(runtimeScene.getObjects("Spaceship2Green"));

gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.First_32layoutCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.First_32layoutCode.GDSpaceship2GreenObjects3.length ;i < len;++i) {
    gdjs.First_32layoutCode.GDSpaceship2GreenObjects3[i].setVariableNumber(gdjs.First_32layoutCode.GDSpaceship2GreenObjects3[i].getVariables().get("speed"), 100);
}
}}

}


{



}


{

gdjs.First_32layoutCode.GDSpaceship2GreenObjects3.createFrom(runtimeScene.getObjects("Spaceship2Green"));

gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.First_32layoutCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.First_32layoutCode.GDSpaceship2GreenObjects3.length ;i < len;++i) {
    gdjs.First_32layoutCode.GDSpaceship2GreenObjects3[i].addPolarForce((gdjs.First_32layoutCode.GDSpaceship2GreenObjects3[i].getDirectionOrAngle()) -90, (gdjs.RuntimeObject.getVariableNumber(gdjs.First_32layoutCode.GDSpaceship2GreenObjects3[i].getVariables().get("speed"))), 0);
}
}}

}


{

gdjs.First_32layoutCode.GDSpaceship2GreenObjects3.createFrom(runtimeScene.getObjects("Spaceship2Green"));

gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs.First_32layoutCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.First_32layoutCode.GDSpaceship2GreenObjects3.length ;i < len;++i) {
    gdjs.First_32layoutCode.GDSpaceship2GreenObjects3[i].addPolarForce((gdjs.First_32layoutCode.GDSpaceship2GreenObjects3[i].getDirectionOrAngle()) +90, (gdjs.RuntimeObject.getVariableNumber(gdjs.First_32layoutCode.GDSpaceship2GreenObjects3[i].getVariables().get("speed"))), 0);
}
}}

}


{

gdjs.First_32layoutCode.GDSpaceship2GreenObjects3.createFrom(runtimeScene.getObjects("Spaceship2Green"));

gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if (gdjs.First_32layoutCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.First_32layoutCode.GDSpaceship2GreenObjects3.length ;i < len;++i) {
    gdjs.First_32layoutCode.GDSpaceship2GreenObjects3[i].addPolarForce((gdjs.First_32layoutCode.GDSpaceship2GreenObjects3[i].getDirectionOrAngle()), (gdjs.RuntimeObject.getVariableNumber(gdjs.First_32layoutCode.GDSpaceship2GreenObjects3[i].getVariables().get("speed"))), 0);
}
}}

}


{

gdjs.First_32layoutCode.GDSpaceship2GreenObjects3.createFrom(runtimeScene.getObjects("Spaceship2Green"));

gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
}if (gdjs.First_32layoutCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.First_32layoutCode.GDSpaceship2GreenObjects3.length ;i < len;++i) {
    gdjs.First_32layoutCode.GDSpaceship2GreenObjects3[i].addPolarForce((gdjs.First_32layoutCode.GDSpaceship2GreenObjects3[i].getDirectionOrAngle()), - (gdjs.RuntimeObject.getVariableNumber(gdjs.First_32layoutCode.GDSpaceship2GreenObjects3[i].getVariables().get("speed"))), 0);
}
}}

}

} //End of subevents

}


}


{



}


{



}


{



{



{ //Subevents

{



}


{

gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects3.createFrom(runtimeScene.getObjects("DarkSpaceship3Green"));

gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.First_32layoutCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects3.length ;i < len;++i) {
    gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects3[i].setVariableNumber(gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects3[i].getVariables().get("speed"), 103);
}
}}

}


{



}


{

gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects3.createFrom(runtimeScene.getObjects("DarkSpaceship3Green"));

gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.First_32layoutCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects3.length ;i < len;++i) {
    gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects3[i].addPolarForce((gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects3[i].getDirectionOrAngle()) -90, (gdjs.RuntimeObject.getVariableNumber(gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects3[i].getVariables().get("speed"))), 0);
}
}}

}


{

gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects3.createFrom(runtimeScene.getObjects("DarkSpaceship3Green"));

gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs.First_32layoutCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects3.length ;i < len;++i) {
    gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects3[i].addPolarForce((gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects3[i].getDirectionOrAngle()) +90, (gdjs.RuntimeObject.getVariableNumber(gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects3[i].getVariables().get("speed"))), 0);
}
}}

}


{

gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects3.createFrom(runtimeScene.getObjects("DarkSpaceship3Green"));

gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if (gdjs.First_32layoutCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects3.length ;i < len;++i) {
    gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects3[i].addPolarForce((gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects3[i].getDirectionOrAngle()), (gdjs.RuntimeObject.getVariableNumber(gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects3[i].getVariables().get("speed"))), 0);
}
}}

}


{

gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects3.createFrom(runtimeScene.getObjects("DarkSpaceship3Green"));

gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
}if (gdjs.First_32layoutCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects3.length ;i < len;++i) {
    gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects3[i].addPolarForce((gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects3[i].getDirectionOrAngle()), - (gdjs.RuntimeObject.getVariableNumber(gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects3[i].getVariables().get("speed"))), 0);
}
}}

}

} //End of subevents

}


}


{



{



{ //Subevents

{



}


{

gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects3.createFrom(runtimeScene.getObjects("DarkSpaceship3Green"));

gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.First_32layoutCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects3.length ;i < len;++i) {
    gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects3[i].setVariableNumber(gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects3[i].getVariables().get("Laser2Blue_speed"), 300);
}
}{runtimeScene.getVariables().get("Laser2Blue_timer").setNumber(0.5);
}}

}


{



}


{

gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects3.createFrom(runtimeScene.getObjects("DarkSpaceship3Green"));
gdjs.First_32layoutCode.GDLaser2BlueObjects3.length = 0;

gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("Laser2Blue_timer")), "");
}if (gdjs.First_32layoutCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "");
}{gdjs.evtTools.object.createObjectOnScene(runtimeScene, context.clearEventsObjectsMap().addObjectsToEventsMap("Laser2Blue", gdjs.First_32layoutCode.GDLaser2BlueObjects3).getEventsObjectsMap(), (( gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects3.length === 0 ) ? 0 :gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects3[0].getPointX("Centre")), (( gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects3.length === 0 ) ? 0 :gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects3[0].getPointY("Centre")), "");
}{for(var i = 0, len = gdjs.First_32layoutCode.GDLaser2BlueObjects3.length ;i < len;++i) {
    gdjs.First_32layoutCode.GDLaser2BlueObjects3[i].setDirectionOrAngle((( gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects3.length === 0 ) ? 0 :gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects3[0].getDirectionOrAngle()));
}
}}

}


{



}


{

gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects3.createFrom(runtimeScene.getObjects("DarkSpaceship3Green"));
gdjs.First_32layoutCode.GDLaser2BlueObjects3.createFrom(runtimeScene.getObjects("Laser2Blue"));

{for(var i = 0, len = gdjs.First_32layoutCode.GDLaser2BlueObjects3.length ;i < len;++i) {
    gdjs.First_32layoutCode.GDLaser2BlueObjects3[i].addPolarForce((gdjs.First_32layoutCode.GDLaser2BlueObjects3[i].getDirectionOrAngle()), (gdjs.RuntimeObject.getVariableNumber(((gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.First_32layoutCode.GDDarkSpaceship3GreenObjects3[0].getVariables()).get("Laser2Blue_speed"))), 0);
}
}
}

} //End of subevents

}


}


{



{



{ //Subevents

{



}


{



}


{


gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.First_32layoutCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("shake_speed").setNumber(0.04);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "shake_timerX");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "shake_timerX");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "shake_timerY");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "shake_timerY");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "shake_timer");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "shake_timer");
}{runtimeScene.getVariables().get("shake_duration").setNumber(0.4);
}{runtimeScene.getVariables().get("shake_scale").setNumber(10);
}{runtimeScene.getVariables().get("follow_Laser2Blue").setString("no");
}}

}


{



}


{


gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("follow_Laser2Blue")) == "no";
}if (gdjs.First_32layoutCode.condition0IsTrue_0.val) {

{ //Subevents

{


gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
gdjs.First_32layoutCode.condition1IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerPaused(runtimeScene, "shake_timer");
}if ( gdjs.First_32layoutCode.condition0IsTrue_0.val ) {
{
{gdjs.First_32layoutCode.conditionTrue_1 = gdjs.First_32layoutCode.condition1IsTrue_0;
gdjs.First_32layoutCode.conditionTrue_1.val = context.triggerOnce(7478996);
}
}}
if (gdjs.First_32layoutCode.condition1IsTrue_0.val) {
{runtimeScene.getVariables().get("cameraX").setNumber(gdjs.evtTools.window.getWindowWidth()/2);
}{runtimeScene.getVariables().get("cameraY").setNumber(gdjs.evtTools.window.getWindowHeight()/2);
}}

}

} //End of subevents
}

}


{


gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("follow_Laser2Blue")) == "yes";
}if (gdjs.First_32layoutCode.condition0IsTrue_0.val) {

{ //Subevents

{

gdjs.First_32layoutCode.GDLaser2BlueObjects4.createFrom(runtimeScene.getObjects("Laser2Blue"));

gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerPaused(runtimeScene, "shake_timer");
}if (gdjs.First_32layoutCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("cameraX").setNumber((( gdjs.First_32layoutCode.GDLaser2BlueObjects4.length === 0 ) ? 0 :gdjs.First_32layoutCode.GDLaser2BlueObjects4[0].getPointX("")));
}{runtimeScene.getVariables().get("cameraY").setNumber((( gdjs.First_32layoutCode.GDLaser2BlueObjects4.length === 0 ) ? 0 :gdjs.First_32layoutCode.GDLaser2BlueObjects4[0].getPointY("")));
}{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.First_32layoutCode.GDLaser2BlueObjects4.length !== 0 ? gdjs.First_32layoutCode.GDLaser2BlueObjects4[0] : null), false, "", 0);
}}

}

} //End of subevents
}

}


{


{gdjs.evtTools.camera.setCameraX(runtimeScene, gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("cameraX")), "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("cameraY")), "", 0);
}
}


{



}


{


gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
gdjs.First_32layoutCode.condition1IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.input.anyKeyPressed(runtimeScene);
}if ( gdjs.First_32layoutCode.condition0IsTrue_0.val ) {
{
{gdjs.First_32layoutCode.conditionTrue_1 = gdjs.First_32layoutCode.condition1IsTrue_0;
gdjs.First_32layoutCode.conditionTrue_1.val = context.triggerOnce(7718276);
}
}}
if (gdjs.First_32layoutCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.unpauseTimer(runtimeScene, "shake_timer");
}}

}


{


gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("shake_duration")), "shake_timer");
}if (gdjs.First_32layoutCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "shake_timer");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "shake_timer");
}}

}


{


gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = !(gdjs.evtTools.runtimeScene.timerPaused(runtimeScene, "shake_timer"));
}if (gdjs.First_32layoutCode.condition0IsTrue_0.val) {

{ //Subevents

{



}


{


gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("follow_Laser2Blue")) == "yes";
}if (gdjs.First_32layoutCode.condition0IsTrue_0.val) {

{ //Subevents

{

gdjs.First_32layoutCode.GDLaser2BlueObjects5.createFrom(runtimeScene.getObjects("Laser2Blue"));

gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
gdjs.First_32layoutCode.condition1IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("cameraX")) == (( gdjs.First_32layoutCode.GDLaser2BlueObjects5.length === 0 ) ? 0 :gdjs.First_32layoutCode.GDLaser2BlueObjects5[0].getPointX(""));
}if ( gdjs.First_32layoutCode.condition0IsTrue_0.val ) {
{
{gdjs.First_32layoutCode.conditionTrue_1 = gdjs.First_32layoutCode.condition1IsTrue_0;
gdjs.First_32layoutCode.conditionTrue_1.val = context.triggerOnce(8869108);
}
}}
if (gdjs.First_32layoutCode.condition1IsTrue_0.val) {
{runtimeScene.getVariables().get("cameraX").setNumber((( gdjs.First_32layoutCode.GDLaser2BlueObjects5.length === 0 ) ? 0 :gdjs.First_32layoutCode.GDLaser2BlueObjects5[0].getPointX("")) + gdjs.random(10));
}}

}


{

gdjs.First_32layoutCode.GDLaser2BlueObjects5.createFrom(runtimeScene.getObjects("Laser2Blue"));

gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("cameraX")) > (( gdjs.First_32layoutCode.GDLaser2BlueObjects5.length === 0 ) ? 0 :gdjs.First_32layoutCode.GDLaser2BlueObjects5[0].getPointX(""));
}if (gdjs.First_32layoutCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.unpauseTimer(runtimeScene, "shake_timerX");
}
{ //Subevents

{


gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("shake_speed")), "shake_timerX");
}if (gdjs.First_32layoutCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("cameraX").sub(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("shake_scale")));
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "shake_timerX");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "shake_timerX");
}}

}

} //End of subevents
}

}


{

gdjs.First_32layoutCode.GDLaser2BlueObjects5.createFrom(runtimeScene.getObjects("Laser2Blue"));

gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("cameraX")) < (( gdjs.First_32layoutCode.GDLaser2BlueObjects5.length === 0 ) ? 0 :gdjs.First_32layoutCode.GDLaser2BlueObjects5[0].getPointX(""));
}if (gdjs.First_32layoutCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.unpauseTimer(runtimeScene, "shake_timerX");
}
{ //Subevents

{


gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("shake_speed")), "shake_timerX");
}if (gdjs.First_32layoutCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("cameraX").add(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("shake_scale")));
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "shake_timerX");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "shake_timerX");
}}

}

} //End of subevents
}

}

} //End of subevents
}

}


{


gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("follow_Laser2Blue")) == "no";
}if (gdjs.First_32layoutCode.condition0IsTrue_0.val) {

{ //Subevents

{


gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
gdjs.First_32layoutCode.condition1IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("cameraX")) == gdjs.evtTools.window.getWindowWidth()/2;
}if ( gdjs.First_32layoutCode.condition0IsTrue_0.val ) {
{
{gdjs.First_32layoutCode.conditionTrue_1 = gdjs.First_32layoutCode.condition1IsTrue_0;
gdjs.First_32layoutCode.conditionTrue_1.val = context.triggerOnce(7480484);
}
}}
if (gdjs.First_32layoutCode.condition1IsTrue_0.val) {
{runtimeScene.getVariables().get("cameraX").setNumber(gdjs.evtTools.window.getWindowWidth()/2 + gdjs.random(10));
}}

}


{


gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("cameraX")) > gdjs.evtTools.window.getWindowWidth()/2;
}if (gdjs.First_32layoutCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.unpauseTimer(runtimeScene, "shake_timerX");
}
{ //Subevents

{


gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("shake_speed")), "shake_timerX");
}if (gdjs.First_32layoutCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("cameraX").sub(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("shake_scale")));
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "shake_timerX");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "shake_timerX");
}}

}

} //End of subevents
}

}


{


gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("cameraX")) < gdjs.evtTools.window.getWindowWidth()/2;
}if (gdjs.First_32layoutCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.unpauseTimer(runtimeScene, "shake_timerX");
}
{ //Subevents

{


gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("shake_speed")), "shake_timerX");
}if (gdjs.First_32layoutCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("cameraX").add(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("shake_scale")));
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "shake_timerX");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "shake_timerX");
}}

}

} //End of subevents
}

}

} //End of subevents
}

}


{



}


{


gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("follow_Laser2Blue")) == "yes";
}if (gdjs.First_32layoutCode.condition0IsTrue_0.val) {

{ //Subevents

{

gdjs.First_32layoutCode.GDLaser2BlueObjects5.createFrom(runtimeScene.getObjects("Laser2Blue"));

gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
gdjs.First_32layoutCode.condition1IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("cameraY")) == (( gdjs.First_32layoutCode.GDLaser2BlueObjects5.length === 0 ) ? 0 :gdjs.First_32layoutCode.GDLaser2BlueObjects5[0].getPointY(""));
}if ( gdjs.First_32layoutCode.condition0IsTrue_0.val ) {
{
{gdjs.First_32layoutCode.conditionTrue_1 = gdjs.First_32layoutCode.condition1IsTrue_0;
gdjs.First_32layoutCode.conditionTrue_1.val = context.triggerOnce(7153324);
}
}}
if (gdjs.First_32layoutCode.condition1IsTrue_0.val) {
{runtimeScene.getVariables().get("cameraY").setNumber((( gdjs.First_32layoutCode.GDLaser2BlueObjects5.length === 0 ) ? 0 :gdjs.First_32layoutCode.GDLaser2BlueObjects5[0].getPointY("")) + gdjs.random(10));
}}

}


{

gdjs.First_32layoutCode.GDLaser2BlueObjects5.createFrom(runtimeScene.getObjects("Laser2Blue"));

gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("cameraY")) > (( gdjs.First_32layoutCode.GDLaser2BlueObjects5.length === 0 ) ? 0 :gdjs.First_32layoutCode.GDLaser2BlueObjects5[0].getPointY(""));
}if (gdjs.First_32layoutCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.unpauseTimer(runtimeScene, "shake_timerY");
}
{ //Subevents

{


gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("shake_speed")), "shake_timerY");
}if (gdjs.First_32layoutCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("cameraY").sub(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("shake_scale")));
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "shake_timerY");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "shake_timerY");
}}

}

} //End of subevents
}

}


{

gdjs.First_32layoutCode.GDLaser2BlueObjects5.createFrom(runtimeScene.getObjects("Laser2Blue"));

gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("cameraY")) < (( gdjs.First_32layoutCode.GDLaser2BlueObjects5.length === 0 ) ? 0 :gdjs.First_32layoutCode.GDLaser2BlueObjects5[0].getPointY(""));
}if (gdjs.First_32layoutCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.unpauseTimer(runtimeScene, "shake_timerY");
}
{ //Subevents

{


gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("shake_speed")), "shake_timerY");
}if (gdjs.First_32layoutCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("cameraY").add(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("shake_scale")));
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "shake_timerY");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "shake_timerY");
}}

}

} //End of subevents
}

}

} //End of subevents
}

}


{


gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("follow_Laser2Blue")) == "no";
}if (gdjs.First_32layoutCode.condition0IsTrue_0.val) {

{ //Subevents

{


gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
gdjs.First_32layoutCode.condition1IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("cameraY")) == gdjs.evtTools.window.getWindowHeight()/2;
}if ( gdjs.First_32layoutCode.condition0IsTrue_0.val ) {
{
{gdjs.First_32layoutCode.conditionTrue_1 = gdjs.First_32layoutCode.condition1IsTrue_0;
gdjs.First_32layoutCode.conditionTrue_1.val = context.triggerOnce(8502428);
}
}}
if (gdjs.First_32layoutCode.condition1IsTrue_0.val) {
{runtimeScene.getVariables().get("cameraY").setNumber(gdjs.evtTools.window.getWindowHeight()/2 + gdjs.random(10));
}}

}


{


gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("cameraY")) > gdjs.evtTools.window.getWindowHeight()/2;
}if (gdjs.First_32layoutCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.unpauseTimer(runtimeScene, "shake_timerY");
}
{ //Subevents

{


gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("shake_speed")), "shake_timerY");
}if (gdjs.First_32layoutCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("cameraY").sub(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("shake_scale")));
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "shake_timerY");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "shake_timerY");
}}

}

} //End of subevents
}

}


{


gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("cameraY")) < gdjs.evtTools.window.getWindowHeight()/2;
}if (gdjs.First_32layoutCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.unpauseTimer(runtimeScene, "shake_timerY");
}
{ //Subevents

{


gdjs.First_32layoutCode.condition0IsTrue_0.val = false;
{
gdjs.First_32layoutCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("shake_speed")), "shake_timerY");
}if (gdjs.First_32layoutCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("cameraY").add(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("shake_scale")));
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "shake_timerY");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "shake_timerY");
}}

}

} //End of subevents
}

}

} //End of subevents
}

}

} //End of subevents
}

}

} //End of subevents

}


}

return;
}
gdjs['First_32layoutCode']= gdjs.First_32layoutCode;
